#1
setwd("C://Users//IT24102648//Desktop//IT24102648")

Delivery_Times<-read.table("Exercise – Lab 05.txt",header= TRUE,sep=",")
#2
names(Delivery_Times)<-c("x1")
attach(Delivery_Times)
fix(Delivery_Times)
histogram<-hist(x1,main="Histogram for Delivery Times",breaks = seq(20, 70,length=10),right=TRUE)

#4
cumulative_freq <- cumsum(histogram$counts)
plot(histogram$mids, cumulative_freq, type="o", xlab="Delivery Time", ylab="Cumulative Frequency", 
     main="Cumulative Frequency Polygon (Ogive)", lwd=2)


